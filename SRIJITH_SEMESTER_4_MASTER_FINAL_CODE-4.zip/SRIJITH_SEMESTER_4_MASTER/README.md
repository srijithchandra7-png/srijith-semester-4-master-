# SRIJITH — SEMESTER 4 MASTER

Production-oriented starter for the premium academic platform described in the specification.

## Stack

- Next.js + React + TypeScript
- Supabase/PostgreSQL
- Supabase Auth
- Supabase Storage / protected object storage
- Server-side authorization and RLS
- Versioned content
- Admin + Student experiences

## What is already scaffolded

- Responsive premium Student UI
- Responsive Admin Control Center UI
- Subject → Chapter → Question flow
- Importance stars
- Bookmark/revision UI entry points
- Chapter PDF UI separation
- Admin master PDF UI separation
- PostgreSQL schema for users, devices, sessions, content, versions, media, feedback, documents, downloads, audit logs and settings
- Indexes for common queries
- Trigram indexes for search
- RLS enabled on sensitive tables
- Environment variable template

## Important

This is a real project scaffold, not a fake database. However, cloud credentials, storage buckets, auth configuration, RLS policies, PDF worker, production CDN/cache and deployment secrets must be configured in the target cloud account before this becomes a live production service.

Do not put the Supabase service-role key in browser/client code.

## Local frontend

1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Fill Supabase URL and anon key.
4. Run:
   `npm install`
   `npm run dev`
5. Open `http://localhost:3000`.

## Database

Create a Supabase project and run `supabase/migrations/001_initial.sql` in the SQL editor or migration workflow.

Then add production RLS policies. The migration intentionally enables RLS without permissive student policies so draft/admin data is not accidentally exposed.

## Production architecture

Browser/PWA
→ HTTPS
→ Next.js server/API
→ Supabase Auth + PostgreSQL
→ protected object storage

For scale:
- database indexes + cursor pagination
- cache published read-heavy content
- CDN for suitable static/public media only
- protected storage for private PDFs
- background worker/queue for PDF generation and analytics aggregation
- stateless web/API instances
- scheduled backups
- audit logs

## PDF rule

Students: CHAPTER_PDF only.

Admin: SEMESTER_PDF allowed.

Never expose the semester master PDF through a student route or client-side list.

## Device rule

A client device identifier is not a security boundary by itself. Use server-side device authorization, authenticated sessions, revocation, and an explicit admin approval flow.
