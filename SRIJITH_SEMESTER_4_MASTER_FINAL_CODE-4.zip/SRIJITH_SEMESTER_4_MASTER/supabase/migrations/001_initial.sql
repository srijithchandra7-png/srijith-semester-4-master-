-- SRIJITH — SEMESTER 4 MASTER
-- PostgreSQL/Supabase production-oriented schema.
create extension if not exists pgcrypto;

create type public.user_role as enum ('ADMIN','STUDENT');
create type public.account_status as enum ('PENDING','ACTIVE','PAUSED','BLOCKED','REVOKED');
create type public.device_status as enum ('PENDING','ACTIVE','REVOKED','BLOCKED');
create type public.request_type as enum ('NEW_DEVICE','REPLACE_DEVICE');
create type public.request_status as enum ('PENDING','APPROVED','REJECTED');
create type public.content_status as enum ('DRAFT','PUBLISHED','ARCHIVED');
create type public.document_type as enum ('CHAPTER_PDF','SEMESTER_PDF');
create type public.download_status as enum ('AVAILABLE','OUTDATED','REMOVED');
create type public.feedback_status as enum ('OPEN','IN_REVIEW','RESOLVED','REJECTED');
create type public.revision_status as enum ('NEEDS_REVISION','COMPLETED');

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.user_role not null default 'STUDENT',
  mobile text unique,
  status public.account_status not null default 'PENDING',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_login_at timestamptz
);

create table public.student_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references public.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  device_identifier_hash text not null,
  device_name text,
  platform text,
  app_version text,
  status public.device_status not null default 'PENDING',
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz,
  approved_at timestamptz,
  revoked_at timestamptz
);
create unique index devices_one_active_per_user on public.devices(user_id) where status='ACTIVE';

create table public.device_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  device_id uuid not null references public.devices(id) on delete cascade,
  request_type public.request_type not null,
  status public.request_status not null default 'PENDING',
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.users(id)
);
create index device_requests_pending_idx on public.device_requests(status, created_at desc);

create table public.sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  device_id uuid references public.devices(id) on delete set null,
  created_at timestamptz not null default now(),
  last_active_at timestamptz,
  expires_at timestamptz not null,
  revoked_at timestamptz
);
create index sessions_user_active_idx on public.sessions(user_id, expires_at desc) where revoked_at is null;

create table public.media (
  id uuid primary key default gen_random_uuid(),
  file_name text not null,
  storage_path text not null,
  media_type text not null,
  file_size bigint,
  width integer,
  height integer,
  uploaded_by uuid references public.users(id),
  created_at timestamptz not null default now()
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text,
  display_order integer not null default 0,
  status public.content_status not null default 'DRAFT',
  background_media_id uuid references public.media(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index subjects_published_order_idx on public.subjects(display_order) where status='PUBLISHED';

create table public.chapters (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  title text not null,
  description text,
  display_order integer not null default 0,
  status public.content_status not null default 'DRAFT',
  background_media_id uuid references public.media(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index chapters_subject_order_idx on public.chapters(subject_id, display_order) where status='PUBLISHED';

create table public.questions (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  current_version_id uuid,
  display_order integer not null default 0,
  status public.content_status not null default 'DRAFT',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  published_at timestamptz
);
create index questions_chapter_order_idx on public.questions(chapter_id, display_order) where status='PUBLISHED';

create table public.question_versions (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  version_number integer not null,
  question_text text not null,
  full_answer text not null,
  importance_level smallint not null check (importance_level between 1 and 5),
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  published_at timestamptz,
  unique(question_id, version_number)
);
create index question_versions_published_idx on public.question_versions(question_id, published_at desc);

alter table public.questions
  add constraint questions_current_version_fk
  foreign key (current_version_id) references public.question_versions(id) on delete set null;

create table public.media_attachments (
  id uuid primary key default gen_random_uuid(),
  media_id uuid not null references public.media(id) on delete cascade,
  entity_type text not null,
  entity_id uuid not null,
  display_order integer not null default 0,
  created_at timestamptz not null default now()
);
create index media_attachments_entity_idx on public.media_attachments(entity_type, entity_id, display_order);

create table public.bookmarks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, question_id)
);
create index bookmarks_user_idx on public.bookmarks(user_id, created_at desc);

create table public.revision_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  status public.revision_status not null default 'NEEDS_REVISION',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, question_id)
);
create index revision_user_status_idx on public.revision_items(user_id, status, updated_at desc);

create table public.recently_viewed (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  view_count integer not null default 1,
  last_viewed_at timestamptz not null default now(),
  unique(user_id, question_id)
);
create index recently_viewed_user_idx on public.recently_viewed(user_id, last_viewed_at desc);

create table public.activity_events (
  id bigint generated always as identity primary key,
  user_id uuid references public.users(id) on delete set null,
  device_id uuid references public.devices(id) on delete set null,
  event_type text not null,
  subject_id uuid references public.subjects(id) on delete set null,
  chapter_id uuid references public.chapters(id) on delete set null,
  question_id uuid references public.questions(id) on delete set null,
  created_at timestamptz not null default now()
);
create index activity_user_time_idx on public.activity_events(user_id, created_at desc);
create index activity_type_time_idx on public.activity_events(event_type, created_at desc);

create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  type text,
  category text not null,
  message text,
  is_anonymous boolean not null default false,
  status public.feedback_status not null default 'OPEN',
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);
create index feedback_status_time_idx on public.feedback(status, created_at desc);
create index feedback_question_idx on public.feedback(question_id, created_at desc);

create table public.feedback_responses (
  id uuid primary key default gen_random_uuid(),
  feedback_id uuid not null references public.feedback(id) on delete cascade,
  admin_id uuid not null references public.users(id),
  response text not null,
  created_at timestamptz not null default now()
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  media_id uuid references public.media(id) on delete set null,
  status public.content_status not null default 'DRAFT',
  created_by uuid references public.users(id),
  published_at timestamptz,
  expires_at timestamptz
);
create index announcements_published_idx on public.announcements(published_at desc) where status='PUBLISHED';

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  type text not null,
  title text not null,
  message text not null,
  related_entity_type text,
  related_entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_unread_idx on public.notifications(user_id, created_at desc) where read_at is null;

create table public.documents (
  id uuid primary key default gen_random_uuid(),
  document_type public.document_type not null,
  subject_id uuid references public.subjects(id) on delete cascade,
  chapter_id uuid references public.chapters(id) on delete cascade,
  title text not null,
  current_version_id uuid,
  status public.content_status not null default 'DRAFT',
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((document_type='CHAPTER_PDF' and chapter_id is not null) or (document_type='SEMESTER_PDF' and chapter_id is null))
);
create index documents_chapter_idx on public.documents(chapter_id) where document_type='CHAPTER_PDF';

create table public.document_versions (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.documents(id) on delete cascade,
  version_number integer not null,
  storage_path text not null,
  file_size bigint,
  checksum text,
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  unique(document_id, version_number)
);

alter table public.documents
  add constraint documents_current_version_fk
  foreign key (current_version_id) references public.document_versions(id) on delete set null;

create table public.download_permissions (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  allow_download boolean not null default false,
  offline_enabled boolean not null default false,
  auto_update boolean not null default true,
  updated_at timestamptz not null default now(),
  unique(chapter_id)
);

create table public.student_downloads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  document_id uuid not null references public.documents(id) on delete cascade,
  document_version_id uuid not null references public.document_versions(id) on delete cascade,
  downloaded_at timestamptz not null default now(),
  last_accessed_at timestamptz,
  status public.download_status not null default 'AVAILABLE',
  unique(user_id, document_id)
);
create index student_downloads_user_idx on public.student_downloads(user_id, downloaded_at desc);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  admin_id uuid references public.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  old_value jsonb,
  new_value jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_time_idx on public.audit_logs(created_at desc);
create index audit_logs_entity_idx on public.audit_logs(entity_type, entity_id, created_at desc);

create table public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references public.users(id)
);

-- Search support. Trigram keeps partial matching practical for question/chapter search.
create extension if not exists pg_trgm;
create index question_text_trgm_idx on public.question_versions using gin (question_text gin_trgm_ops);
create index chapter_title_trgm_idx on public.chapters using gin (title gin_trgm_ops);

-- RLS baseline: deny-by-default; application should add carefully-scoped policies.
alter table public.users enable row level security;
alter table public.student_profiles enable row level security;
alter table public.devices enable row level security;
alter table public.device_requests enable row level security;
alter table public.sessions enable row level security;
alter table public.subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.questions enable row level security;
alter table public.question_versions enable row level security;
alter table public.media enable row level security;
alter table public.media_attachments enable row level security;
alter table public.bookmarks enable row level security;
alter table public.revision_items enable row level security;
alter table public.recently_viewed enable row level security;
alter table public.activity_events enable row level security;
alter table public.feedback enable row level security;
alter table public.feedback_responses enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.documents enable row level security;
alter table public.document_versions enable row level security;
alter table public.download_permissions enable row level security;
alter table public.student_downloads enable row level security;
alter table public.audit_logs enable row level security;
alter table public.app_settings enable row level security;

-- NOTE: production policies should be added after defining auth helpers.
-- Never ship a policy that lets a STUDENT read drafts, audit logs, all users,
-- or SEMESTER_PDF documents.

