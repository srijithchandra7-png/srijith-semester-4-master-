import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SRIJITH — SEMESTER 4 MASTER",
  description: "Premium private academic platform"
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}