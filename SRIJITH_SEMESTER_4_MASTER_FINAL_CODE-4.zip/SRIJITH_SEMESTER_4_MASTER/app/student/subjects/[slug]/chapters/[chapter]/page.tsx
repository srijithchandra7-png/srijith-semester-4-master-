import Link from "next/link";
const qs=[
 {n:1,star:"★★★★★",text:"Explain the central concept and discuss its significance with suitable examples."},
 {n:2,star:"★★★★☆",text:"Describe the major characteristics and explain how they relate to the chapter."},
 {n:3,star:"★★★★★",text:"Discuss the topic critically and construct a structured answer."},
 {n:4,star:"★★★☆☆",text:"Write a concise note on the important points covered in this chapter."}
];
export default async function Chapter({params}:{params:Promise<{slug:string,chapter:string}>}) {
 const p=await params;
 return <div className="shell"><div className="topbar"><div className="brand">SRIJITH<small>SEMESTER 4 MASTER</small></div><Link className="btn secondary" href={`/student/subjects/${p.slug}`}>← Chapters</Link></div>
 <main className="main"><div className="eyebrow">Chapter {p.chapter}</div><h1 className="title">Master Questions</h1><div className="row"><input className="search" placeholder="Search within chapter..." /><button className="btn secondary">★★★★★</button><button className="btn secondary">★★★★☆</button></div>
 <div className="card" style={{marginTop:18}}>{qs.map(q=><div className="question" key={q.n}><div className="row"><span className="pill">QUESTION {String(q.n).padStart(2,"0")}</span><span className="stars">{q.star}</span></div><h3>{q.text}</h3><div className="row"><Link className="btn" href={`/student/question/${q.n}`}>VIEW ANSWER</Link><button className="btn secondary">BOOKMARK</button><button className="btn secondary">REVISION</button></div></div>)}</div>
 <div className="section card"><div className="eyebrow">Controlled Offline PDF</div><h3>Chapter {p.chapter} PDF</h3><p className="muted">Available only through the authenticated in-app document flow.</p><button className="btn">↓ DOWNLOAD CHAPTER PDF</button></div>
 </main></div>
}