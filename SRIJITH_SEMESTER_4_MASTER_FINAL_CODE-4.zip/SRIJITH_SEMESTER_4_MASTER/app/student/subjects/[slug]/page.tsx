import Link from "next/link";

const chapters = Array.from({length:8},(_,i)=>({n:i+1,title:["Language & Linguistics","Prose","Poetry","Grammar","Writing","Critical Study","Revision Set","Master Questions"][i],q:18+i*3}));

export default async function SubjectPage({params}:{params:Promise<{slug:string}>}) {
  const {slug}=await params;
  const name=slug.split("-").map(x=>x[0]?.toUpperCase()+x.slice(1)).join(" ");
  return <div className="shell"><div className="topbar"><div className="brand">SRIJITH<small>SEMESTER 4 MASTER</small></div><Link className="btn secondary" href="/student">← Home</Link></div>
    <main className="main"><div className="eyebrow">Subject</div><h1 className="title">{name}</h1><p className="muted">8 Chapters · Published content</p>
      <div className="grid grid-2" style={{marginTop:25}}>{chapters.map(c=><div className="card chapter" key={c.n}><div className="row" style={{justifyContent:"space-between"}}><span className="pill">CHAPTER {String(c.n).padStart(2,"0")}</span><span className="stars">★★★★★</span></div><h2 style={{fontFamily:"Georgia,serif",fontWeight:500}}>{c.title}</h2><p className="muted">{c.q} Questions</p><div className="row"><Link className="btn" href={`/student/subjects/${slug}/chapters/${c.n}`}>OPEN</Link><button className="btn secondary">↓ PDF</button></div></div>)}</div>
    </main></div>
}