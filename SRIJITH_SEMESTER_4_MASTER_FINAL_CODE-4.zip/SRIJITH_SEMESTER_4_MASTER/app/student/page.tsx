import Link from "next/link";

const subjects = ["Bengali","English","Geography","Education","Political Science","Computer Application"];

export default function Student() {
  return <div className="shell">
    <div className="topbar"><div className="brand">SRIJITH<small>SEMESTER 4 MASTER</small></div><span className="pill">ACTIVE</span></div>
    <div className="layout">
      <aside className="sidebar">
        {["HOME","SUBJECTS","SEARCH","BOOKMARKS","DOWNLOADS","PROFILE"].map((x,i)=><button className={"navbtn "+(i===0?"active":"")} key={x}>{x}</button>)}
      </aside>
      <main className="main">
        <div className="eyebrow">Student App</div>
        <h1 className="title">Continue learning.</h1>
        <div className="card">
          <div className="eyebrow">Continue Learning</div>
          <h2 style={{marginBottom:5}}>Political Science · Chapter 03</h2>
          <p className="muted">Last opened question · ★★★★★</p>
          <button className="btn">CONTINUE →</button>
        </div>
        <section className="section"><div className="eyebrow">Subjects</div><div className="grid grid-3" style={{marginTop:14}}>
          {subjects.map((s,i)=><Link href={`/student/subjects/${encodeURIComponent(s.toLowerCase().replaceAll(" ","-"))}`} className="card subject" key={s}><div><div className="eyebrow">Subject 0{i+1}</div><h2 style={{fontFamily:"Georgia,serif",fontWeight:500}}>{s}</h2></div><div className="row"><span className="pill">12 Chapters</span><span className="pill">157 Questions</span></div></Link>)}
        </div></section>
        <section className="section grid grid-2">
          <div className="card"><div className="eyebrow">Recently Viewed</div><h3>Bengali · Chapter 04</h3><p className="muted">Question 12 · ★★★★★</p></div>
          <div className="card"><div className="eyebrow">Need Revision</div><h3>7 questions</h3><p className="muted">Your saved revision queue.</p></div>
        </section>
      </main>
    </div>
    <div className="mobile-nav">{["HOME","SUBJECTS","SEARCH","BOOKMARKS","DOWNLOADS","PROFILE"].map((x,i)=><button className={i===0?"active":""} key={x}>{x}</button>)}</div>
  </div>
}