import Link from "next/link";
export default async function Question({params}:{params:Promise<{id:string}>}) {
 const {id}=await params;
 return <div className="shell"><div className="topbar"><div className="brand">SRIJITH<small>SEMESTER 4 MASTER</small></div><Link className="btn secondary" href="/student">← Home</Link></div>
 <main className="main"><div className="eyebrow">Question {id}</div><div className="row" style={{margin:"12px 0"}}><span className="stars">★★★★★</span><span className="pill">EXAM IMPORTANCE</span></div>
 <article className="card"><div className="eyebrow">Question</div><h2 style={{lineHeight:1.6,fontFamily:"Georgia,serif"}}>Explain the central concept and discuss its significance with suitable examples.</h2><hr style={{border:0,borderTop:"1px solid #e5e5e2",margin:"30px 0"}}/><div className="eyebrow">Full Answer</div><div className="answer" style={{marginTop:12}}>A complete, structured answer will be stored in the versioned question content and returned by the secure backend only when the authenticated student is authorized to access the published version.\n\nThe answer editor supports headings, paragraphs, lists, diagrams and attached images.</div></article>
 <div className="card section"><h3>Was this answer helpful?</h3><div className="row"><button className="btn">HELPFUL</button><button className="btn secondary">NOT HELPFUL</button><button className="btn secondary">SEND FEEDBACK</button><button className="btn secondary">BOOKMARK</button></div></div>
 </main></div>
}