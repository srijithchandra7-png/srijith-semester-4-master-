"use client";

import { useMemo, useState } from "react";
import {
  ArrowLeft, ArrowRight, Bell, Bookmark, BookOpen, Check, ChevronRight,
  CircleUserRound, Download, FileText, LayoutDashboard, Menu, MessageSquare,
  MoreHorizontal, Search, Settings, Shield, Smartphone, Sparkles, Users, X
} from "lucide-react";

const subjects = [
  {name:"Bengali", count:12, questions:210},
  {name:"English", count:10, questions:178},
  {name:"Geography", count:9, questions:196},
  {name:"Education", count:8, questions:157},
  {name:"Political Science", count:8, questions:182},
  {name:"Computer Application", count:9, questions:224},
];

const questions = [
  {id:1, title:"Explain the central concept of the chapter and discuss its significance with suitable examples.", stars:5},
  {id:2, title:"Describe the major characteristics and explain their relationship with the chapter.", stars:4},
  {id:3, title:"Discuss the topic critically and construct a structured examination answer.", stars:5},
  {id:4, title:"Write a concise note on the most important points covered in this chapter.", stars:3},
  {id:5, title:"Analyse the important terms, concepts and their practical significance.", stars:4},
];

function Stars({n}:{n:number}) { return <span className="stars">{"★".repeat(n)}<span className="dim">{"★".repeat(5-n)}</span></span> }
function Card({children,className="",onClick}:{children:React.ReactNode,className?:string,onClick?:()=>void}) { return <div onClick={onClick} className={`card ${onClick?"clickable":""} ${className}`}>{children}</div> }

export default function Home(){
  const [mode,setMode] = useState<"student"|"admin">("student");
  const [screen,setScreen] = useState("home");
  const [subject,setSubject] = useState("Bengali");
  const [chapter,setChapter] = useState(1);
  const [selected,setSelected] = useState(1);
  const [query,setQuery] = useState("");
  const [bookmarks,setBookmarks] = useState<number[]>([2]);
  const [revision,setRevision] = useState<number[]>([3,5]);
  const [toast,setToast] = useState("");
  const [feedbackOpen,setFeedbackOpen] = useState(false);

  const notify=(text:string)=>{setToast(text);setTimeout(()=>setToast(""),1700)};
  const openChapter=(s:string,c:number)=>{setSubject(s);setChapter(c);setScreen("chapter")};
  const toggleBookmark=(id:number)=>setBookmarks(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id]);
  const toggleRevision=(id:number)=>setRevision(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id]);
  const visibleQuestions=useMemo(()=>questions.filter(q=>q.title.toLowerCase().includes(query.toLowerCase())),[query]);

  const studentNav=[
    ["home","HOME",LayoutDashboard],["subjects","SUBJECTS",BookOpen],["search","SEARCH",Search],
    ["bookmarks","BOOKMARKS",Bookmark],["downloads","DOWNLOADS",Download],["profile","PROFILE",CircleUserRound]
  ] as const;
  const adminNav=[
    ["dashboard","DASHBOARD",LayoutDashboard],["students","STUDENTS",Users],["subjectsA","SUBJECTS",BookOpen],
    ["questionsA","QUESTIONS",FileText],["media","MEDIA",Sparkles],["pdf","PDF EXPORT",Download],
    ["feedback","FEEDBACK",MessageSquare],["security","SECURITY",Shield],["settings","SETTINGS",Settings]
  ] as const;

  const shellNav=mode==="student"?studentNav:adminNav;

  function Student(){
    if(screen==="chapter") return <Chapter />;
    if(screen==="question") return <Question />;
    if(screen==="subjects") return <Subjects />;
    if(screen==="search") return <SearchPage />;
    if(screen==="bookmarks") return <Saved />;
    if(screen==="downloads") return <Downloads />;
    if(screen==="profile") return <Profile />;
    return <Home />;
  }

  function Home(){return <>
    <div className="eyebrow">Student App · Semester 4</div>
    <h1 className="title">Continue learning.</h1>
    <p className="muted lead">A controlled academic workspace for questions, answers, revision and chapter-wise offline documents.</p>
    <Card className="heroCard"><div><div className="eyebrow">CONTINUE LEARNING</div><h2>Political Science · Chapter 03</h2><p className="muted">Last opened question · <Stars n={5}/></p></div><button className="btn" onClick={()=>openChapter("Political Science",3)}>CONTINUE <ArrowRight size={16}/></button></Card>
    <div className="sectionHead"><div><div className="eyebrow">YOUR SEMESTER</div><h2>Subjects</h2></div><button className="textBtn" onClick={()=>setScreen("subjects")}>View all <ArrowRight size={14}/></button></div>
    <div className="grid grid3">{subjects.map((s,i)=><Card key={s.name} className="subjectCard" onClick={()=>openChapter(s.name,1)}><div><span className="number">0{i+1}</span><h3>{s.name}</h3><p className="muted">{s.count} chapters · {s.questions} questions</p></div><ChevronRight size={17}/></Card>)}</div>
    <div className="grid grid2 section"><Card><div className="eyebrow">NEED REVISION</div><div className="bigNumber">{revision.length}</div><p className="muted">Questions waiting in your revision queue.</p><button className="btn secondary" onClick={()=>setScreen("bookmarks")}>OPEN QUEUE</button></Card><Card><div className="eyebrow">RECENTLY VIEWED</div><h3>Bengali · Chapter 04</h3><p className="muted">Question 12 · <Stars n={5}/></p><button className="btn secondary" onClick={()=>openChapter("Bengali",4)}>OPEN CHAPTER</button></Card></div>
  </>}

  function Subjects(){return <><div className="eyebrow">Subjects</div><h1 className="title">Your semester.</h1><div className="grid grid3">{subjects.map((s,i)=><Card key={s.name} className="largeCard" onClick={()=>openChapter(s.name,1)}><span className="number">0{i+1}</span><h2>{s.name}</h2><p className="muted">{s.count} chapters · {s.questions} questions</p><button className="btn secondary">OPEN SUBJECT</button></Card>)}</div></>}

  function Chapter(){return <><div className="breadcrumb" onClick={()=>setScreen("subjects")}><ArrowLeft size={15}/> {subject}</div><div className="row between"><div><div className="eyebrow">CHAPTER {String(chapter).padStart(2,"0")}</div><h1 className="title">Master Questions.</h1></div><span className="pill">157 QUESTIONS</span></div><div className="toolbar"><div className="searchWrap"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search within chapter..."/></div><button className="btn secondary">★★★★★</button><button className="btn secondary">★★★★☆</button></div><Card className="questionList">{visibleQuestions.map(q=><div className="question" key={q.id}><div className="row between"><span className="pill">QUESTION {String(q.id).padStart(2,"0")}</span><Stars n={q.stars}/></div><h3>{q.title}</h3><div className="row"><button className="btn" onClick={()=>{setSelected(q.id);setScreen("question")}}>VIEW ANSWER</button><button className={`btn secondary ${bookmarks.includes(q.id)?"selected":""}`} onClick={()=>toggleBookmark(q.id)}><Bookmark size={14}/> {bookmarks.includes(q.id)?"SAVED":"BOOKMARK"}</button><button className={`btn secondary ${revision.includes(q.id)?"selected":""}`} onClick={()=>toggleRevision(q.id)}>REVISION</button></div></div>)}</Card><Card className="downloadCard"><div><div className="eyebrow">CONTROLLED OFFLINE DOCUMENT</div><h3>Chapter {String(chapter).padStart(2,"0")} PDF</h3><p className="muted">Only the current chapter is available to student accounts.</p></div><button className="btn" onClick={()=>notify("Chapter PDF added to My Downloads")}> <Download size={15}/> DOWNLOAD CHAPTER PDF</button></Card></>}

  function Question(){const q=questions.find(x=>x.id===selected)||questions[0];return <><div className="breadcrumb" onClick={()=>setScreen("chapter")}><ArrowLeft size={15}/> Chapter {String(chapter).padStart(2,"0")}</div><div className="eyebrow">QUESTION {String(q.id).padStart(2,"0")}</div><h1 className="title questionTitle">{q.title}</h1><div className="row"><Stars n={q.stars}/><span className="pill">EXAM IMPORTANCE</span></div><Card className="answerCard"><div className="eyebrow">FULL ANSWER</div><div className="answerText"><p><strong>Introduction</strong></p><p>This is the structured answer area for the published version of the question. The production system stores the content as a versioned record and returns only the currently published answer to an authorized student.</p><p><strong>Core discussion</strong></p><p>The answer can contain headings, paragraphs, bullet points, examples, diagrams and attached images. The editor preserves previous versions so administrators can review changes and restore an earlier publication when necessary.</p><p><strong>Conclusion</strong></p><p>The final answer is designed for examination use: clear structure, accurate content and controlled revision history.</p></div></Card><Card><div className="row between"><div><h3>Was this answer helpful?</h3><p className="muted">Your feedback improves future versions.</p></div><div className="row"><button className="btn" onClick={()=>notify("Thanks for your feedback")}> <Check size={15}/> HELPFUL</button><button className="btn secondary" onClick={()=>setFeedbackOpen(true)}>NOT HELPFUL</button><button className="btn secondary" onClick={()=>setFeedbackOpen(true)}>SEND FEEDBACK</button></div></div></Card></>}

  function SearchPage(){return <><div className="eyebrow">Global Search</div><h1 className="title">Find anything.</h1><div className="searchWrap large"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Questions, chapters, concepts..."/></div><div className="section">{visibleQuestions.map(q=><Card key={q.id} className="result" onClick={()=>{setSelected(q.id);setScreen("question")}}><div><div className="eyebrow">{subject} · CHAPTER 04</div><h3>{q.title}</h3><Stars n={q.stars}/></div><ChevronRight size={17}/></Card>)}</div></>}
  function Saved(){return <><div className="eyebrow">Personal Library</div><h1 className="title">Bookmarks & revision.</h1><div className="grid grid2"><Card><div className="eyebrow">BOOKMARKS</div><div className="bigNumber">{bookmarks.length}</div><p className="muted">Saved questions for quick access.</p></Card><Card><div className="eyebrow">NEED REVISION</div><div className="bigNumber">{revision.length}</div><p className="muted">Questions in your revision queue.</p></Card></div><Card className="section"><div className="eyebrow">SAVED QUESTIONS</div>{questions.filter(q=>bookmarks.includes(q.id)||revision.includes(q.id)).map(q=><div className="question" key={q.id}><div className="row between"><h3>{q.title}</h3><Stars n={q.stars}/></div><button className="btn secondary" onClick={()=>{setSelected(q.id);setScreen("question")}}>OPEN</button></div>)}</Card></>}
  function Downloads(){return <><div className="eyebrow">Offline Library</div><h1 className="title">My downloads.</h1><div className="grid grid2"><Card><div className="eyebrow">BENGALI</div><h3>Chapter 03</h3><p className="muted">PDF v1.2 · Available offline</p><button className="btn secondary">OPEN OFFLINE</button></Card><Card><div className="eyebrow">GEOGRAPHY</div><h3>Chapter 01</h3><p className="muted">UPDATE AVAILABLE · v1.1</p><button className="btn" onClick={()=>notify("Document updated")}>UPDATE</button></Card></div></>}
  function Profile(){return <><div className="eyebrow">Account</div><h1 className="title">Profile.</h1><Card className="profileGrid"><div><span>Mobile</span><strong>+91 ••••••••••</strong></div><div><span>Status</span><strong>ACTIVE</strong></div><div><span>Authorized device</span><strong>Android · Active</strong></div><div><span>Last active</span><strong>Just now</strong></div></Card></>}

  function Admin(){
    const adminCards=[['TOTAL STUDENTS','128'],['ACTIVE','114'],['PENDING APPROVALS','7'],['BLOCKED','7'],['QUESTIONS','1,247'],['FEEDBACK REPORTS','23']];
    if(screen==="students") return <><div className="eyebrow">Students</div><h1 className="title">Access control.</h1><Card><table className="table"><thead><tr><th>Mobile</th><th>Status</th><th>Device</th><th>Last Active</th><th></th></tr></thead><tbody>{[['+91 98••••12','PENDING','Android','—'],['+91 87••••42','ACTIVE','Android','Today'],['+91 70••••81','ACTIVE','Android','Yesterday'],['+91 62••••33','BLOCKED','Android','Sep 17']].map(r=><tr key={r[0]}>{r.map(x=><td key={x}>{x}</td>)}<td><button className="btn secondary" onClick={()=>notify("Student status updated")}>MANAGE</button></td></tr>)}</tbody></table></Card></>;
    if(screen==="questionsA") return <AdminEditor />;
    if(screen==="pdf") return <AdminPDF />;
    if(screen==="feedback") return <AdminFeedback />;
    return <><div className="eyebrow">Admin Control Center</div><h1 className="title">System overview.</h1><div className="grid grid3">{adminCards.map(c=><Card key={c[0]}><div className="eyebrow">{c[0]}</div><div className="bigNumber">{c[1]}</div></Card>)}</div><div className="section grid grid2"><Card><div className="eyebrow">CONTENT PIPELINE</div><h3>CREATE → DRAFT → PREVIEW → VERIFY → PUBLISH</h3><p className="muted">Only published content reaches students.</p><button className="btn" onClick={()=>setScreen("questionsA")}>OPEN QUESTION EDITOR</button></Card><Card><div className="eyebrow">PDF EXPORT</div><h3>Complete Semester Master</h3><p className="muted">Admin-only master document generation.</p><button className="btn" onClick={()=>setScreen("pdf")}>OPEN PDF CONTROL</button></Card></div></>;
  }
  function AdminEditor(){return <><div className="eyebrow">Question Editor</div><h1 className="title">Build the answer bank.</h1><Card><label className="fieldLabel">QUESTION<textarea placeholder="Write the complete question..."/></label><label className="fieldLabel">EXAM IMPORTANCE<div className="row">{[5,4,3,2,1].map(n=><button key={n} className="btn secondary" onClick={()=>notify(`Importance set to ${n}/5`)}><Stars n={n}/></button>)}</div></label><label className="fieldLabel">FULL ANSWER<textarea className="answerInput" placeholder="Write the full structured answer..."/></label><div className="row"><button className="btn secondary" onClick={()=>notify("Draft saved")}>SAVE DRAFT</button><button className="btn secondary" onClick={()=>notify("Preview opened")}>PREVIEW</button><button className="btn" onClick={()=>notify("Content published")}>PUBLISH</button></div></Card><Card className="section"><div className="eyebrow">VERSION HISTORY</div><p><strong>v1.2</strong> · Current</p><p className="muted">v1.1 · Previous · v1.0 · Previous</p></Card></>}
  function AdminPDF(){return <><div className="eyebrow">PDF Export</div><h1 className="title">Document control.</h1><div className="grid grid2"><Card><div className="eyebrow">ADMIN ONLY</div><h2>Complete Semester Master PDF</h2><p className="muted">All published subjects, chapters, questions, importance and answers.</p><div className="row"><button className="btn" onClick={()=>notify("Master PDF generation queued")}>GENERATE</button><button className="btn secondary">PREVIEW</button><button className="btn secondary">DOWNLOAD</button></div></Card><Card><div className="eyebrow">STUDENT DOCUMENTS</div><h2>Chapter PDFs</h2><p className="muted">Generate and version individual chapter documents.</p><button className="btn secondary" onClick={()=>notify("Chapter PDF manager opened")}>MANAGE CHAPTER PDFs</button></Card></div></>}
  function AdminFeedback(){return <><div className="eyebrow">Feedback Center</div><h1 className="title">Improve the content.</h1><div className="grid grid4">{[['TOTAL','23'],['HELPFUL','11'],['NOT HELPFUL','12'],['POSSIBLE ERRORS','4']].map(x=><Card key={x[0]}><div className="eyebrow">{x[0]}</div><div className="bigNumber">{x[1]}</div></Card>)}</div><Card className="section"><div className="row between"><h3>Latest reports</h3><span className="pill">LATEST</span></div><p>Question 12 · Answer seems incorrect · OPEN</p><div className="row"><button className="btn secondary">REVIEW</button><button className="btn secondary">EDIT CONTENT</button><button className="btn" onClick={()=>notify("Feedback resolved")}>RESOLVE</button></div></Card></>}

  return <div className="app"><header className="topbar"><div className="brand">SRIJITH<small>{mode==="student"?"SEMESTER 4 MASTER":"ADMIN CONTROL CENTER"}</small></div><div className="row"><span className="status">{mode==="student"?"ACTIVE":"ADMIN"}</span><button className="btn secondary" onClick={()=>{setMode(mode==="student"?"admin":"student");setScreen(mode==="student"?"dashboard":"home")}}>{mode==="student"?"Admin Control":"Student App"}</button></div></header><div className="layout"><aside className="sidebar">{shellNav.map(([id,label,Icon])=><button key={id} className={`navbtn ${screen===id?"active":""}`} onClick={()=>setScreen(id)}><Icon size={16}/>{label}</button>)}</aside><main className="main">{mode==="student"?<Student/>:<Admin/>}</main></div><nav className="mobileNav">{shellNav.slice(0,5).map(([id,label,Icon])=><button key={id} className={screen===id?"active":""} onClick={()=>setScreen(id)}><Icon size={17}/><span>{label}</span></button>)}</nav>{toast&&<div className="toast">{toast}</div>}{feedbackOpen&&<div className="overlay" onClick={()=>setFeedbackOpen(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="row between"><h2>Send Feedback</h2><button className="iconBtn" onClick={()=>setFeedbackOpen(false)}><X size={18}/></button></div><label className="fieldLabel">CATEGORY<select><option>Answer seems incorrect</option><option>Difficult to understand</option><option>Too short</option><option>Question unclear</option><option>Diagram/Image needed</option><option>Other</option></select></label><label className="fieldLabel">MESSAGE<textarea placeholder="Describe the issue..."/></label><button className="btn" onClick={()=>{setFeedbackOpen(false);notify("Feedback submitted")}}>SUBMIT FEEDBACK</button></div></div>}</div>
}
